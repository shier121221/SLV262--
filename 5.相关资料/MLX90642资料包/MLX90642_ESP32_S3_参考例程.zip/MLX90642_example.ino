#include <Arduino.h>
#include <Wire.h>
extern "C" {
  #include "MLX90642.h"
  #include "MLX90642_depends.h"
}

#define IR_ADDR 0x66  

constexpr int SDA_PIN = 8;
constexpr int SCL_PIN = 9;

void setup()
{
    Serial.begin(115200);
    
    MLX90642_I2CInit(SDA_PIN,SCL_PIN);
    MLX90642_WakeUp(IR_ADDR);
    
    while(MLX90642_Init(IR_ADDR))
    {
        int init_status = MLX90642_Init(IR_ADDR);
        if (init_status != 0) {
            Serial.print("MLX90642 初始化失败，错误码: ");
            Serial.println(init_status);
            Serial.println("I2C scan:");
            for (uint8_t a = 1; a < 127; a++) {
              Wire.beginTransmission(a);
              if (Wire.endTransmission() == 0) {
                Serial.print("found 0x"); Serial.println(a, HEX);
              }
            }
        } else {
            Serial.println("MLX90642 初始化成功");
        }
        delay(500);
     }
    Serial.println("MLX90642 init OK");

    MLX90642_SetMeasMode (IR_ADDR, MLX90642_CONT_MEAS_MODE);
    MLX90642_SetRefreshRate(IR_ADDR, MLX90642_REF_RATE_8HZ);
    delay(300);                  // 等两帧
}

uint16_t frame[769];

void loop()
{
    int ret = MLX90642_GetImage(IR_ADDR, frame);
    if (ret == 0) {
        Serial.println("------ Frame Data ------");
        for (int row = 0; row < 24; row++) {
            for (int col = 0; col < 32; col++) {
                int index = row * 32 + col;
                Serial.print(frame[index]*0.02);
                Serial.print('\t'); 
            }
            Serial.println();
        }
    } else {
        Serial.print("GetImage err = ");
        Serial.println(ret);
    }
    delay(10);
}
