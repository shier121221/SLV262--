

#ifndef _MLX90642_DEPENDS_H_
#define _MLX90642_DEPENDS_H_

#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

int MLX90642_I2CRead(uint8_t addr, uint16_t reg, uint16_t words, uint16_t *buf);
int MLX90642_Config (uint8_t addr, uint16_t reg, uint16_t data);
int MLX90642_I2CCmd(uint8_t addr, uint16_t cmd);
int MLX90642_WakeUp(uint8_t addr);
void MLX90642_Wait_ms(uint16_t ms);
void MLX90642_I2CInit(uint8_t MLX_SDA,uint8_t MLX_SCL) ;
#ifdef __cplusplus
}
#endif
#endif
