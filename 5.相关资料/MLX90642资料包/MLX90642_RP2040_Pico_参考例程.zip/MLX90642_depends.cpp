#include <Arduino.h>
#include <Wire.h>
#include "MLX90642_depends.h"
#define BLOCK_WORDS   128                // 128 words = 256 bytes
int MLX90642_I2CRead(uint8_t addr, uint16_t reg,
                     uint16_t words, uint16_t *buf)
{
    while (words) {
        uint16_t thisBlock = (words > BLOCK_WORDS) ? BLOCK_WORDS : words;

        Wire.beginTransmission(addr);
        Wire.write(reg >> 8);
        Wire.write(reg & 0xFF);
        if (Wire.endTransmission(false)) return -1;

        uint16_t bytes = thisBlock * 2;
        Wire.requestFrom(addr, bytes);        // 不加第三个参数
        for (uint16_t i = 0; i < thisBlock; i++) {
            if (Wire.available() < 2) return -2;
            uint8_t hi = Wire.read();
            uint8_t lo = Wire.read();
            *buf++ = (hi << 8) | lo;
        }

        reg   += thisBlock;   // 下一子地址
        words -= thisBlock;   // 剩余
    }
    return 0;
}


int MLX90642_Config(uint8_t slaveAddr, uint16_t writeAddress, uint16_t wData) {
    Wire.beginTransmission(slaveAddr);
    Wire.write(writeAddress >> 8);      // 地址高字节
    Wire.write(writeAddress & 0xFF);    // 地址低字节
    Wire.write(wData >> 8);             // 数据高字节
    Wire.write(wData & 0xFF);           // 数据低字节
    return Wire.endTransmission(true);  // 返回传输状态 (0=成功)
}

int MLX90642_I2CCmd(uint8_t slaveAddr, uint16_t i2c_cmd) {
    Wire.beginTransmission(slaveAddr);
    Wire.write(i2c_cmd >> 8);           // 命令高字节
    Wire.write(i2c_cmd & 0xFF);         // 命令低字节
    return Wire.endTransmission(true);  // 返回传输状态
}


void MLX90642_Wait_ms(uint16_t time_ms) {
    delay(time_ms);  // Arduino 标准延时
}

void MLX90642_I2CInit(uint8_t MLX_SDA, uint8_t MLX_SCL)
{
#if defined(ARDUINO_ARCH_ESP32) || defined(ARDUINO_ARCH_RP2040)
    Wire.setSDA(MLX_SDA);
    Wire.setSCL(MLX_SCL);
#endif
    Wire.begin();
#if WIRE_HAS_SETCLOCK
    Wire.setClock(400000);        // 先 400 kHz，排错更容易
#endif
}

int MLX90642_WakeUp(uint8_t slaveAddr)
{
    Wire.beginTransmission(slaveAddr);
    Wire.endTransmission();       // 普通 START + STOP
    delay(40);                    // datasheet ≥33 ms
    return 0;
}
